const mysql = require('mysql2/promise');
const dotenv = require('dotenv');

dotenv.config();

const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    ssl: { rejectUnauthorized: false }, // Désactive la vérification SSL
};


async function testConnection() {
    try {
        const connection = await mysql.createConnection(dbConfig);
        console.log('Connexion réussie à la base de données');
        const [rows] = await connection.query('SELECT * FROM Users');
        console.log('Données récupérées :', rows);
        connection.end();
    } catch (err) {
        console.error('Erreur lors de la connexion à la base de données :', err);
    }
}

testConnection();
