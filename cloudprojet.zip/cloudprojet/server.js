const express = require('express');
const axios = require('axios');
const dotenv = require('dotenv');
const path = require('path');
const sessionKeys = {}; 

dotenv.config(); // Charger les variables d'environnement

const app = express();
app.use(express.urlencoded({ extended: true })); // Gérer les formulaires
app.use(express.static(path.join(__dirname, 'public'))); // Fichiers statiques (CSS, JS)

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Configuration de la base MySQL (pour potentiels usages futurs)
const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASS,
  database: process.env.DB_NAME,
};

// URL de la Function App et Web PubSub
const FUNCTION_APP_URL = 'https://quiz-function-app.azurewebsites.net'; // URL de la Function App Azure
const WEB_PUBSUB_URL = process.env.WEB_PUBSUB_URL || "https://pubsub-projet.webpubsub.azure.com";

// Page d'accueil
app.get('/', (req, res) => {
  res.render('index');
});

// Page de connexion
app.get('/login', (req, res) => {
  res.render('login');
});

// Page de création de compte
app.get('/register', (req, res) => {
  res.render('register');
});

// Traitement de la création de compte
app.post('/register', async (req, res) => {
  const { username, password } = req.body;

  try {
    // Appel à la Function App pour enregistrer un nouvel utilisateur
    const response = await axios.post(`${FUNCTION_APP_URL}/api/userauth`, {
      action: 'register',
      username,
      password,
    });

    res.redirect('/login');
  } catch (err) {
    console.error('Erreur lors de la création de compte :', err.response?.data || err.message);
    res.status(400).send(err.response?.data?.message || 'Erreur lors de la création de compte.');
  }
});

// Traitement de la connexion
app.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const response = await axios.post(`${FUNCTION_APP_URL}/api/userauth`, {
      action: "login",
      username,
      password,
    });

    const { user } = response.data;

    if (!user || !user.id) {
      throw new Error("Erreur : l'utilisateur ou l'ID est manquant dans la réponse.");
    }

    // Rediriger vers /gamemode avec les paramètres username et user_id
    res.redirect(`/gamemode?username=${user.username}&user_id=${user.id}`);
  } catch (err) {
    console.error("Erreur lors de la connexion :", err.response?.data || err.message);
    res.status(401).send("Nom d'utilisateur ou mot de passe incorrect.");
  }
});





// Tableau de bord
app.get("/dashboard", (req, res) => {
  const { username, user_id } = req.query;

  if (!username || !user_id) {
    return res.redirect('/login');
  }

  res.render("dashboard", { username, user_id });
});



// Route pour afficher le quiz
app.get('/quiz', (req, res) => {
  const username = req.query.username;
  if (!username) {
      return res.redirect('/login'); // Redirection si `username` manquant
  }
  res.render('quiz', { username });
});


// Page des résultats
app.get("/results", async (req, res) => {
  const { username, user_id } = req.query;

  if (!user_id || !username) {
    return res.status(400).send("Erreur : données utilisateur manquantes.");
  }

  try {
    const response = await axios.post(
      "https://quiz-function-app.azurewebsites.net/api/calculateScore?code=ZR1VsyCss1_ooYPLhipIlAJF7mBB8FgsPHOntjIE7uq1AzFuT2WJXg==",
      { user_id }
    );

    const { correct_answers, total_questions, score } = response.data;

    res.render("results", {
      username, // Passer le nom d'utilisateur
      user_id,
      correct_answers,
      total_questions,
      score,
    });
  } catch (error) {
    console.error("Erreur lors de la récupération du score :", error.message);
    res.render("results", {
      username,
      user_id,
      correct_answers: undefined,
      total_questions: undefined,
      score: undefined,
    });
  }
});

// Route pour choisir le mode de jeu
app.get("/gamemode", (req, res) => {
  const { username, user_id } = req.query;

  if (!username || !user_id) {
      console.error("Données utilisateur absentes pour gamemode.");
      return res.status(400).send("Erreur de données utilisateur.");
  }

  res.render("gamemode", { username, user_id });
});



// Tableau de bord solo
app.get("/dashboardsolo", (req, res) => {
  const { username, user_id } = req.query;
  if (!username || !user_id) return res.redirect("/login");
  res.render("dashboardsolo", { username, user_id });
});

// Quiz solo
app.get("/quizsolo", (req, res) => {
  const { username, user_id } = req.query;
  if (!username || !user_id) return res.redirect("/login");
  res.render("quizsolo", { username, user_id });
});

app.get("/resultssolo", async (req, res) => {
  const { username, user_id } = req.query;

  console.log("Route /resultssolo appelée :", { username, user_id });

  if (!user_id || !username) {
      console.error("Données utilisateur manquantes. Redirection...");
      return res.redirect("/gamemode");
  }

  try {
      const response = await axios.post(
          "https://quiz-function-app.azurewebsites.net/api/calculateScoreSolo?code=9fyuKOur3PXWmQJds3YuksSXckCyFOKQMmU1FqxTeOzAAzFuBaMGNA==",
          { user_id }
      );

      const { correct_answers, total_questions, score } = response.data;

      res.render("resultssolo", {
          username, // Nom d'utilisateur
          user_id,
          correct_answers,
          total_questions,
          score,
      });
  } catch (error) {
      console.error("Erreur lors de la récupération du score :", error.message);
      res.render("resultssolo", {
          username,
          user_id,
          correct_answers: undefined,
          total_questions: undefined,
          score: undefined,
      });
  }
});

app.post('/logout', (req, res) => {
  // Si vous utilisez des sessions, détruisez-les ici
  if (req.session) {
      req.session.destroy(err => {
          if (err) {
              console.error("Erreur lors de la destruction de la session :", err);
              return res.status(500).send("Erreur lors de la déconnexion.");
          }
          res.redirect('/login'); // Redirection après déconnexion
      });
  } else {
      res.redirect('/login'); // Redirige directement si aucune session
  }
});










// Démarrage du serveur
app.listen(process.env.PORT || 3000, () => {
  console.log(`Server is running on port ${process.env.PORT || 3000}`);
});
