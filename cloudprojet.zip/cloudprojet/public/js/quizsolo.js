document.addEventListener("DOMContentLoaded", async () => {
    const questionElement = document.getElementById("question");
    const optionsElement = document.getElementById("options");
    const nextButton = document.getElementById("nextQuestion");
    const quitButton = document.getElementById("quitQuiz");
    const resultButton = document.createElement("button");
    const sessionKey = Math.random().toString(36).substring(2, 12);

    console.log("Session Key:", sessionKey);

    let currentQuestionId = null;
    let selectedOption = null;
    let remainingQuestions = 10;

    resultButton.id = "showResult";
    resultButton.textContent = "Passer au score";
    resultButton.style.display = "none"; // Hidden initially
    resultButton.style.background = "linear-gradient(120deg, #ff9a9e, #fad0c4)";
    resultButton.style.color = "white";
    resultButton.style.border = "none";
    resultButton.style.padding = "1rem 2rem";
    resultButton.style.borderRadius = "50px";
    resultButton.style.cursor = "pointer";
    resultButton.style.marginTop = "1rem";

    // Append the result button to the container
    document.querySelector(".container").appendChild(resultButton);

    // Load a question from the API
    async function loadQuestion() {
        try {
            const response = await fetch(
                "https://quiz-function-app.azurewebsites.net/api/fetchQuestionsAndPushSolo?code=mygMQg4atSepRXBLUGProZYeGEJgnpnyxOKj82jQo5ZwAzFu1F6gfw==",
                { method: "POST" }
            );

            if (!response.ok) throw new Error("Failed to fetch question.");

            const question = await response.json();
            console.log("Question received:", question);

            if (!question || !question.question_text) {
                throw new Error("Invalid question data.");
            }

            currentQuestionId = question.id;
            questionElement.textContent = question.question_text;
            optionsElement.innerHTML = `
                <button class="option" data-option="a">${question.option_a}</button>
                <button class="option" data-option="b">${question.option_b}</button>
                <button class="option" data-option="c">${question.option_c}</button>
                <button class="option" data-option="d">${question.option_d}</button>
            `;

            document.querySelectorAll(".option").forEach((button) => {
                button.addEventListener("click", () => {
                    selectedOption = button.dataset.option;
                    document.querySelectorAll(".option").forEach((btn) =>
                        btn.classList.remove("selected")
                    );
                    button.classList.add("selected");
                });
            });
        } catch (error) {
            console.error("Error loading question:", error.message);
            questionElement.textContent = "Erreur : impossible de charger la question.";
        }
    }

    // Send the user's answer to the API
    async function sendAnswer() {
        if (!selectedOption) {
            alert("Veuillez sélectionner une réponse avant de continuer !");
            return false;
        }

        const userId = new URLSearchParams(window.location.search).get("user_id");

        const body = {
            user_id: userId,
            question_id: currentQuestionId,
            selected_option: selectedOption,
            session_key: sessionKey,
        };

        try {
            const response = await fetch(
                "https://quiz-function-app.azurewebsites.net/api/addResponseToQueueSolo?code=rAscZ0hYfvwdQ9ezPIu_9vJ1m8Ajf9l1YnygX-ud7D4BAzFut_Tceg==",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(body),
                }
            );

            if (!response.ok) throw new Error("Failed to send answer.");

            console.log("Answer sent successfully:", body);
            return true;
        } catch (error) {
            console.error("Error sending answer:", error.message);
            alert("Erreur lors de l'envoi de la réponse. Veuillez réessayer.");
            return false;
        }
    }

    nextButton.addEventListener("click", async () => {
        const answerSent = await sendAnswer();

        if (!answerSent) return;

        remainingQuestions--;
        if (remainingQuestions > 0) {
            selectedOption = null;
            await loadQuestion();
        } else {
            nextButton.style.display = "none";
            resultButton.style.display = "block";
        }
    });

    quitButton.addEventListener("click", async () => {
        try {
            await fetch(
                "https://quiz-function-app.azurewebsites.net/api/clearQueueSolo?code=6Nz9jIcV1stpK96cU6fx7zvUnl0C1KImGpjvFMSSzqd4AzFu_CtsSQ==",
                { method: "POST" }
            );

            const username = new URLSearchParams(window.location.search).get("username");
            const userId = new URLSearchParams(window.location.search).get("user_id");
            window.location.href = `/gamemode?username=${username}&user_id=${userId}`;
        } catch (error) {
            console.error("Error clearing queue:", error.message);
            alert("Impossible de quitter le quiz. Veuillez réessayer.");
        }
    });

    resultButton.addEventListener("click", async () => {
        const username = new URLSearchParams(window.location.search).get("username");
        const userId = new URLSearchParams(window.location.search).get("user_id");

        try {
            console.log("Storing responses from queue...");
            const storeResponse = await fetch(
                "https://quiz-function-app.azurewebsites.net/api/storeResponsesFromQueueSolo?code=4bP7qjTx0mSChIXzMEJ5OTP6syCwG5HmpkeuyapoExHiAzFuO7QHSQ==",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                }
            );

            if (!storeResponse.ok) throw new Error("Failed to store responses.");

            console.log("Responses stored successfully.");
            window.location.href = `/resultssolo?username=${username}&user_id=${userId}`;
        } catch (error) {
            console.error("Error storing responses:", error.message);
            alert("Une erreur s'est produite lors du stockage des réponses.");
        }
    });

    await loadQuestion();
});
