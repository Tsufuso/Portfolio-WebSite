document.addEventListener("DOMContentLoaded", async () => {
    const questionElement = document.getElementById("question");
    const optionsElement = document.getElementById("options");
    const nextButton = document.getElementById("nextQuestion");
    const quitButton = document.getElementById("quitQuiz");
    const resultButton = document.getElementById("showResult");
    const resultButtonContainer = document.getElementById("resultButtonContainer");
    ///////////////////////////////////
    const sessionKey = Math.random().toString(36).substring(2, 12); // Génération aléatoire
  console.log("Clé de session générée :", sessionKey);

  // Stocker la clé dans une variable globale ou un champ caché
  window.sessionKey = sessionKey;
  //////////////////////////////////

    let connection;
    let currentQuestionId = null;
    let selectedOption = null;
    let isLoadingQuestion = false;
    let remainingQuestions = 10; // Total des questions
    const userResponses = []; // Stockage local des réponses

    // Démarrage de la connexion WebSocket
    async function startWebSocket() {
        try {
            console.log("Tentative de connexion au WebSocket...");

            const response = await fetch(
                "https://quiz-function-app.azurewebsites.net/api/negotiate?code=wFlBD1NUShum3giIVX380e0IE6GQzSk2YbUADSLsIvjXAzFub_0UuQ==",
                { method: "POST" }
            );

            if (!response.ok) throw new Error("Échec de la négociation Web PubSub.");

            const { url } = await response.json();

            connection = new WebSocket(url);

            connection.onopen = async () => {
                console.log("Connexion WebSocket établie.");
                await fetchNextQuestion();
            };

            connection.onmessage = (event) => handleNewQuestion(event.data);
            connection.onerror = (error) => console.error("Erreur WebSocket :", error);
            connection.onclose = () => console.log("Connexion WebSocket fermée.");
        } catch (error) {
            console.error("Erreur lors du démarrage du WebSocket :", error);
        }
    }

    // Gestion des nouvelles questions
    function handleNewQuestion(data) {
        const questionData = JSON.parse(data);
    
        if (questionData.type === "question") {
            console.log("Nouvelle question reçue :", questionData);
    
            currentQuestionId = questionData.id;
            selectedOption = null;
    
            // Affiche la question et les options reçues
            questionElement.textContent = questionData.question_text;
            optionsElement.innerHTML = `
                <button class="option" data-option="a">${questionData.option_a}</button>
                <button class="option" data-option="b">${questionData.option_b}</button>
                <button class="option" data-option="c">${questionData.option_c}</button>
                <button class="option" data-option="d">${questionData.option_d}</button>
            `;
    
            // Ajoute des écouteurs pour les boutons d'options
            document.querySelectorAll(".option").forEach((button) => {
                button.addEventListener("click", () => {
                    selectedOption = button.dataset.option;
                    document.querySelectorAll(".option").forEach((btn) => btn.classList.remove("selected"));
                    button.classList.add("selected");
                });
            });
        } else {
            console.error("Type de message inattendu :", questionData);
        }
    }
    

    // Récupération de la prochaine question
    async function fetchNextQuestion() {
        if (isLoadingQuestion) {
            alert("Veuillez patienter, la question est en cours de chargement.");
            return;
        }
    
        if (remainingQuestions <= 0) {
            console.log("Toutes les questions ont été récupérées.");
            resultButtonContainer.style.display = "block";
            nextButton.style.display = "none";
            return;
        }
    
        try {
            isLoadingQuestion = true;
            remainingQuestions--;
    
            const response = await fetch(
                "https://quiz-function-app.azurewebsites.net/api/fetchQuestionsAndPush?code=k1i7yParmUzKgD4jZsTYwrV6bZL46mPljIUsvYwNQzUhAzFut3MVxA==",
                { method: "POST" }
            );
    
            if (!response.ok) throw new Error("Échec lors de la demande de la prochaine question.");
            console.log("Prochaine question demandée avec succès.");
        } catch (error) {
            console.error("Erreur lors de la demande de la prochaine question :", error);
        } finally {
            isLoadingQuestion = false;
        }
    }
    

    // Envoi de la réponse à la file d'attente
    async function sendAnswerToQueue(userId, questionId, selectedOption) {
        try {
            const body = {
                user_id: userId,
                question_id: questionId,
                selected_option: selectedOption,
                session_key: sessionKey, // Utilisation de la clé générée
            };

            console.log("Données envoyées à l'API :", body);

            const response = await fetch(
                "https://quiz-function-app.azurewebsites.net/api/addResponseToQueue?code=GB8L0U_uCXS05KnGMRuYh8NbvPiGeXWL_uBMGGIj4_mnAzFuJc8mhw==",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(body),
                }
            );

            if (!response.ok) {
                throw new Error("Erreur lors de l'envoi de la réponse à la file d'attente.");
            }

            console.log("Réponse ajoutée avec succès.");
        } catch (error) {
            console.error("Erreur lors de l'ajout de la réponse :", error);
        }
    }
    

    // Stockage local des réponses utilisateur
    function storeUserResponse(userId, questionId, selectedOption) {
        const existingIndex = userResponses.findIndex((res) => res.question_id === questionId);

        if (existingIndex !== -1) {
            userResponses[existingIndex].selected_option = selectedOption;
        } else {
            userResponses.push({ user_id: userId, question_id: questionId, selected_option: selectedOption });
        }

        console.log("Réponses stockées localement :", userResponses);
    }

    // Envoi de toutes les réponses stockées localement
    async function sendAllResponsesToQueue() {
        try {
            for (const response of userResponses) {
                await sendAnswerToQueue(response.user_id, response.question_id, response.selected_option);
            }
            console.log("Toutes les réponses ont été envoyées à la file d'attente.");
        } catch (error) {
            console.error("Erreur lors de l'envoi des réponses :", error);
        }
    }

    // Écouteur pour "Question suivante"
    nextButton.addEventListener("click", async () => {
        if (!selectedOption) {
            alert("Veuillez sélectionner une réponse avant de continuer !");
            return;
        }

        const userId = new URLSearchParams(window.location.search).get("user_id");
        console.log("Données pour l'envoi :", {
            user_id: userId,
            question_id: currentQuestionId,
            selected_option: selectedOption,
        });

        if (!userId || !currentQuestionId || !selectedOption) {
            alert("Données manquantes. Vérifiez les champs.");
            return;
        }

        await sendAnswerToQueue(userId, currentQuestionId, selectedOption);
        await fetchNextQuestion();
    });
    // Écouteur pour "Quitter"
    quitButton.addEventListener("click", async () => {
        try {
            const response = await fetch(
                "https://quiz-function-app.azurewebsites.net/api/clearQueue?code=gRIcERhppAt1o7Nu3DQxq6zzfz8BtSU-6pbIheoxOW0QAzFusBu01g==",
                { method: "POST" }
            );

            if (response.ok) {
                console.log("File d'attente vidée avec succès.");
                const username = new URLSearchParams(window.location.search).get("username");
                const userId = new URLSearchParams(window.location.search).get("user_id");
                window.location.href = `/dashboard?username=${username}&user_id=${userId}`;
            } else {
                throw new Error("Échec de la suppression de la file d'attente.");
            }
        } catch (error) {
            console.error("Erreur lors de la suppression de la file d'attente :", error);
            alert("Impossible de quitter le quiz. Veuillez réessayer.");
        }
    });

    // Écouteur pour "Passer au score"
    resultButton.addEventListener("click", async () => {
        const username = new URLSearchParams(window.location.search).get("username");
        const userId = new URLSearchParams(window.location.search).get("user_id");
    
        if (!userId) {
            alert("Identifiant utilisateur manquant. Veuillez réessayer.");
            return;
        }
    
        try {
            // Stocker les réponses dans la base de données
            console.log("Stockage des réponses dans la base de données...");
            const storeResponse = await fetch(
                "https://quiz-function-app.azurewebsites.net/api/storeResponsesFromQueue?code=c5PGxPT2mpTUBX2n8iOp7GF3rq5TwwPgKYBYqOTZBNNcAzFuk2jWwA==",
                {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                }
            );
    
            if (!storeResponse.ok) {
                throw new Error("Erreur lors du stockage des réponses.");
            }
    
            console.log("Réponses stockées avec succès.");
    
            // Redirection vers la page des résultats
            window.location.href = `/results?username=${username}&user_id=${userId}`;
        } catch (error) {
            console.error("Erreur lors du stockage des réponses :", error);
            alert("Une erreur s'est produite. Veuillez réessayer.");
        }
    });    
    
    await startWebSocket();
});
