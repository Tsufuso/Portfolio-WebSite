const API_BASE_URL = "https://quiz-function-app.azurewebsites.net/api/userauth";

// Login
async function login(username, password) {
    try {
        console.log("Tentative de connexion...");

        const response = await fetch(`${API_BASE_URL}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "login", username, password }),
        });

        const responseData = await response.json();

        if (!response.ok) {
            // En cas d'erreur, déclenche une alerte avec le message renvoyé par le serveur
            throw new Error(responseData.message || "Erreur de connexion");
        }

        // Message de succès
        window.location.href = `/gamemode?username=${responseData.user.username}&user_id=${responseData.user.id}`; // Redirige après connexion
    } catch (err) {
        alert(err.message); // Affiche l'erreur spécifique
        console.error("Erreur lors de la connexion :", err);
    }
}

// Register
async function register(username, password) {
    try {
        console.log("Tentative d'inscription...");

        const response = await fetch(`${API_BASE_URL}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "register", username, password }),
        });

        const responseData = await response.json();

        if (!response.ok) {
            // En cas d'erreur, déclenche une alerte avec le message renvoyé par le serveur
            throw new Error(responseData.message || "Erreur d'inscription");
        }

        // Message de succès
        window.location.href = "/login"; // Redirige vers la page de connexion
    } catch (err) {
        alert(err.message); // Affiche l'erreur spécifique
        console.error("Erreur lors de l'inscription :", err);
    }
}