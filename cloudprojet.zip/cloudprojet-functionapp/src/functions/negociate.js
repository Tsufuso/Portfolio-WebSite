const { app } = require("@azure/functions");
const { WebPubSubServiceClient } = require("@azure/web-pubsub");

// Création du client Web PubSub
const client = new WebPubSubServiceClient(process.env.PUBSUB_CONNECTION_STRING, "quiz");

app.http("negotiate", {
    methods: ["POST"],
    authLevel: "function",
    handler: async (req, context) => {
        try {
            context.log("Starting Web PubSub negotiation...");

            // Générer une URL WebSocket pour le client
            const connectionInfo = await client.getClientAccessToken();

            context.log("Generated connection info:", connectionInfo);

            // Retourner l'URL et le token dans une chaîne JSON explicite
            return {
                status: 200,
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*", // Permet les requêtes CORS pendant le développement
                },
                body: JSON.stringify({
                    url: connectionInfo.url, // URL WebSocket générée
                }),
            };
        } catch (error) {
            context.log.error("Error during Web PubSub negotiation:", error);

            return {
                status: 500,
                headers: {
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*",
                },
                body: JSON.stringify({
                    error: "Failed to generate Web PubSub client connection.",
                    details: error.message,
                }),
            };
        }
    },
});
