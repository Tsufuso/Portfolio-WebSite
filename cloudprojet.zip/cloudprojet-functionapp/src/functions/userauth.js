const { app } = require('@azure/functions');
const mysql = require('mysql2/promise');

// Configuration de la base de données
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME,
    ssl: false, // Remplacez par `true` et ajoutez `ca` pour les connexions sécurisées si nécessaire
};

app.http('userauth', {
    methods: ['POST'],
    authLevel: 'anonymous',
    handler: async (request, context) => {
        context.log(`Requête reçue pour l'URL "${request.url}"`);

        let connection;

        try {
            const { action, username, password } = await request.json();

            if (!action || !username || !password) {
                return {
                    status: 400,
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ message: "Action, nom d'utilisateur et mot de passe sont requis." }),
                };
            }

            connection = await mysql.createConnection(dbConfig);

            if (action === 'register') {
                const [existingUser] = await connection.execute(
                    'SELECT id FROM Users WHERE username = ?',
                    [username]
                );

                if (existingUser.length > 0) {
                    return {
                        status: 400,
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ message: 'Nom d’utilisateur déjà pris.' }),
                    };
                }

                await connection.execute(
                    'INSERT INTO Users (username, password_hash) VALUES (?, ?)',
                    [username, password]
                );

                return {
                    status: 200,
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ message: 'Compte créé avec succès.' }),
                };
            } else if (action === 'login') {
                const [rows] = await connection.execute(
                    'SELECT id, username FROM Users WHERE username = ? AND password_hash = ?',
                    [username, password]
                );

                if (rows.length > 0) {
                    const user = rows[0];
                    return {
                        status: 200,
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                            message: 'Connexion réussie.',
                            user, // Inclut `id` et `username`
                        }),
                    };
                } else {
                    return {
                        status: 401,
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({ message: 'Nom d’utilisateur ou mot de passe incorrect.' }),
                    };
                }
            } else {
                return {
                    status: 400,
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ message: 'Action non valide. Utilisez "register" ou "login".' }),
                };
            }
        } catch (err) {
            return {
                status: 500,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ message: 'Erreur interne du serveur.', details: err.message }),
            };
        } finally {
            if (connection) {
                await connection.end();
            }
        }
    },
});
