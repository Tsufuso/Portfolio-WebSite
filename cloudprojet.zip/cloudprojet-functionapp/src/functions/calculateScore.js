const { app } = require("@azure/functions");
const { QueueServiceClient } = require("@azure/storage-queue");
const mysql = require("mysql2/promise");

// Configuration des services Azure
const queueServiceClient = QueueServiceClient.fromConnectionString(process.env.AZURE_STORAGE_CONNECTION_STRING);
const queueName = "player-responses"; // Nom de la file d'attente

app.http("calculateScore", {
  methods: ["POST"], // Méthode HTTP autorisée
  authLevel: "function", // Niveau d'authentification
  handler: async (req, context) => {
    let dbConnection;

    try {
      context.log("Début du calcul du score...");

      // Récupérer les données de la requête
      const data = await req.json();
      const { user_id } = data;

      // Vérification que le champ user_id est fourni
      if (!user_id) {
        return {
          status: 400,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "Paramètre requis : user_id." }),
        };
      }

      // Connexion à la file d'attente
      const queueClient = queueServiceClient.getQueueClient(queueName);
      context.log(`QueueClient initialisé pour la file : ${queueName}`);

      // Vérifiez si la file existe
      const exists = await queueClient.exists();
      if (!exists) {
        context.log.error(`La file '${queueName}' n'existe pas.`);
        return {
          status: 404,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "File d'attente introuvable." }),
        };
      }

      // Récupérer les messages pour le user_id donné
      const messagesResponse = await queueClient.peekMessages({ numberOfMessages: 32 }); // Récupérer les messages visibles
      const userMessages = messagesResponse.peekedMessageItems.filter((message) => {
        try {
          const decodedMessage = JSON.parse(Buffer.from(message.messageText, "base64").toString("utf8"));
          return decodedMessage.user_id === user_id; // Filtrer les messages pour cet user_id
        } catch (err) {
          context.log.error(`Erreur lors du parsing d'un message : ${err.message}`);
          return false;
        }
      });

      if (userMessages.length === 0) {
        context.log(`Aucun message trouvé pour user_id = ${user_id}`);
        return {
          status: 404,
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ error: "Aucune réponse trouvée pour cet utilisateur." }),
        };
      }

      // Récupérer le session_key du premier message trouvé (on suppose une session par utilisateur)
      const { session_key } = JSON.parse(
        Buffer.from(userMessages[0].messageText, "base64").toString("utf8")
      );

      context.log(`Session Key récupérée : ${session_key}`);

      // Connexion à la base de données MySQL
      dbConnection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
      });

      context.log("Connexion à MySQL réussie.");

      // Requête SQL pour calculer le score basé sur user_id et session_key
      const [result] = await dbConnection.execute(
        `SELECT COUNT(*) AS correct_answers 
         FROM useranswers 
         JOIN questions ON useranswers.question_id = questions.id 
         WHERE useranswers.user_id = ? 
         AND useranswers.session_key = ? 
         AND useranswers.selected_option = questions.correct_option`,
        [user_id, session_key]
      );

      const correctAnswers = result[0]?.correct_answers || 0; // Nombre de réponses correctes
      const totalQuestions = 10; // Ajustez selon vos besoins

      context.log(`Score calculé : ${correctAnswers} / ${totalQuestions}`);

      // Insérer le score dans la table `scores`
      await dbConnection.execute(
        `INSERT INTO scores (user_id, total_score, created_at, session_key) VALUES (?, ?, NOW(), ?)`,
        [user_id, correctAnswers, session_key]
      );

      context.log("Score inséré avec succès dans la base de données.");

      // Requête SQL pour récupérer le meilleur score (max total_score pour cet utilisateur)
      const [bestScoreResult] = await dbConnection.execute(
        `SELECT MAX(total_score) AS best_score 
         FROM scores 
         WHERE user_id = ?`,
        [user_id]
      );

      const bestScore = bestScoreResult[0]?.best_score || 0; // Meilleur score

      context.log(`Meilleur score récupéré : ${bestScore}`);

      // Retourner le score actuel et le meilleur score
      return {
        status: 200,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          correct_answers: correctAnswers,
          total_questions: totalQuestions,
          score: `${correctAnswers}/${totalQuestions}`,
          best_score: bestScore, // Inclure le meilleur score
        }),
      };
    } catch (error) {
      context.log.error("Erreur lors du calcul du score :", error);

      // Gestion des erreurs internes
      return {
        status: 500,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          error: "Erreur interne lors du calcul du score.",
          details: error.message,
        }),
      };
    } finally {
      if (dbConnection) {
        await dbConnection.end();
        context.log("Connexion MySQL fermée.");
      }
    }
  },
});
