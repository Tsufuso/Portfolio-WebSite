const { app } = require("@azure/functions");
const { QueueServiceClient } = require("@azure/storage-queue");

app.http("clearQueue", {
  methods: ["POST"],
  authLevel: "function",
  handler: async (req, context) => {
    try {
      context.log("Début de la suppression de la file d'attente quiz-questions...");

      // Connexion au service de file d'attente Azure
      const queueServiceClient = QueueServiceClient.fromConnectionString(process.env.AZURE_STORAGE_CONNECTION_STRING);
      const queueName = "quiz-questions"; // Nom de la file d'attente à supprimer
      const queueClient = queueServiceClient.getQueueClient(queueName);

      // Vérifie si la file d'attente existe
      const exists = await queueClient.exists();
      if (!exists) {
        context.log(`La file d'attente '${queueName}' n'existe pas.`);
        return {
          status: 404,
          body: { message: `La file d'attente '${queueName}' n'existe pas.` },
        };
      }

      // Supprime tous les messages dans la file d'attente
      await queueClient.clearMessages();
      context.log(`Tous les messages de la file d'attente '${queueName}' ont été supprimés.`);

      return {
        status: 200,
        body: { message: "File d'attente quiz-questions vidée avec succès." },
      };
    } catch (error) {
      context.log.error("Erreur lors de la suppression de la file d'attente :", error);

      return {
        status: 500,
        body: { error: "Échec de la suppression de la file d'attente.", details: error.message },
      };
    }
  },
});
