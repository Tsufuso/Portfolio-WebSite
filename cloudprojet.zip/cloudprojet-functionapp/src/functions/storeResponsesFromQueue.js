const { app } = require("@azure/functions");
const { QueueServiceClient } = require("@azure/storage-queue");
const mysql = require("mysql2/promise");

// Nom de la file d'attente
const queueName = "player-responses";

// Fonction HTTP pour stocker les réponses
app.http("storeResponsesFromQueue", {
  methods: ["POST"],
  authLevel: "function",
  handler: async (req, context) => {
    const connectionString = process.env.AZURE_STORAGE_CONNECTION_STRING;
    let dbConnection;

    try {
      context.log("Début du traitement des réponses de la file d'attente...");

      // Récupérer les données de la requête
      const data = await req.json();
      const { user_id, session_key } = data;

      // Vérification que le `user_id` et la `session_key` sont fournis
      if (!user_id || !session_key) {
        return {
          status: 400,
          body: { error: "Paramètres requis : user_id et session_key." },
        };
      }

      context.log(`Traitement des réponses pour user_id=${user_id}, session_key=${session_key}`);

      // Connexion à MySQL
      dbConnection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
      });
      
      context.log("Connexion à MySQL réussie.");

      // Connexion à la file d'attente Azure
      const queueServiceClient = QueueServiceClient.fromConnectionString(connectionString);
      const queueClient = queueServiceClient.getQueueClient(queueName);

      const queueExists = await queueClient.exists();
      if (!queueExists) {
        context.log.error(`La file '${queueName}' n'existe pas.`);
        return { status: 404, body: "File d'attente introuvable." };
      }

      // Lire tous les messages pertinents
      const messagesToProcess = [];
      let messagesBatch;

      do {
        messagesBatch = await queueClient.receiveMessages({ numberOfMessages: 32, visibilityTimeout: 1 });
        if (messagesBatch.receivedMessageItems) {
          for (const message of messagesBatch.receivedMessageItems) {
            try {
              const decodedMessage = JSON.parse(
                Buffer.from(message.messageText, "base64").toString("utf-8")
              );

              // Filtrer les messages pour `user_id` et `session_key` correspondant
              if (decodedMessage.user_id === user_id && decodedMessage.session_key === session_key) {
                messagesToProcess.push({
                  ...decodedMessage,
                  messageId: message.messageId,
                  popReceipt: message.popReceipt, // Nécessaire pour la suppression
                });
              }
            } catch (err) {
              context.log.error("Erreur lors du parsing d'un message :", err.message);
            }
          }
        }
      } while (messagesBatch.receivedMessageItems && messagesBatch.receivedMessageItems.length > 0);

      if (messagesToProcess.length === 0) {
        context.log(`Aucun message trouvé pour user_id=${user_id} et session_key=${session_key}`);
        return { status: 404, body: "Aucune réponse trouvée pour cet utilisateur." };
      }

      context.log(
        `${messagesToProcess.length} message(s) trouvé(s) pour user_id=${user_id} et session_key=${session_key}`
      );

      // Enregistrement des réponses dans MySQL
      for (const message of messagesToProcess) {
        try {
          const { user_id, question_id, selected_option, session_key } = message;

          // Validation des champs
          if (!user_id || !question_id || !selected_option || !session_key) {
            context.log.error("Message invalide, ignoré :", message);
            continue;
          }

          // Enregistrement dans la base de données
          await dbConnection.execute(
            "INSERT INTO useranswers (user_id, question_id, selected_option, session_key) VALUES (?, ?, ?, ?)",
            [user_id, question_id, selected_option, session_key]
          );

          context.log(`Réponse insérée avec succès pour question_id=${question_id}, session_key=${session_key}`);
        } catch (err) {
          context.log.error("Erreur lors de l'insertion d'une réponse :", err.message);
        }
      }

      context.log("Toutes les réponses pertinentes ont été traitées avec succès.");
      return {
        status: 200,
        body: { message: "Réponses stockées avec succès dans la base de données." },
      };
    } catch (error) {
      context.log.error("Erreur dans storeResponsesFromQueue :", error.message);
      return {
        status: 500,
        body: { error: "Échec du traitement des réponses.", details: error.message },
      };
    } finally {
      if (dbConnection) {
        await dbConnection.end();
        context.log("Connexion MySQL fermée.");
      }
    }
  },
});
