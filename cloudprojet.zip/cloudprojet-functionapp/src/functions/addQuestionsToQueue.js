const { app } = require("@azure/functions");
const { QueueServiceClient } = require("@azure/storage-queue");
const mysql = require("mysql2/promise");

app.http("addQuestionsToQueue", {
  methods: ["POST"],
  authLevel: "function", // Clé d'accès requise
  handler: async (req, context) => {
    let connection;
    try {
      context.log("Début de l'ajout des questions à la file d'attente...");

      // Connexion à la base de données MySQL
      connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
      });
      context.log("Connecté à la base de données MySQL.");

      // Récupère 11 questions aléatoires depuis la base
      const [rows] = await connection.execute(
        "SELECT id, question_text, option_a, option_b, option_c, option_d, correct_option FROM questions ORDER BY RAND() LIMIT 10"
      );
      context.log(`Questions récupérées depuis la base de données : ${rows.length}`);

      if (rows.length === 0) {
        return {
          status: 404,
          body: "Aucune question disponible à ajouter à la file d'attente.",
        };
      }

      // Connexion au service de file d'attente Azure
      const queueServiceClient = QueueServiceClient.fromConnectionString(process.env.AZURE_STORAGE_CONNECTION_STRING);
      const queueName = "quiz-questions"; // Nom de la file d'attente
      const queueClient = queueServiceClient.getQueueClient(queueName);

      // Vérifie si la file existe, sinon la crée
      await queueClient.createIfNotExists();
      context.log(`File d'attente '${queueName}' initialisée.`);

      // Ajoute chaque question récupérée à la file
      for (const question of rows) {
        const message = Buffer.from(JSON.stringify(question)).toString("base64"); // Encodage en base64
        await queueClient.sendMessage(message);
        context.log(`Question ajoutée à la file : ID=${question.id}, texte="${question.question_text}"`);
      }

      context.log("Toutes les questions ont été ajoutées avec succès à la file d'attente.");

      return {
        status: 200,
        body: "Questions added to the queue successfully.",
      };
    } catch (error) {
      context.log.error("Erreur lors de l'ajout des questions :", error);

      return {
        status: 500,
        body: `Failed to add questions to the queue: ${error.message}`,
      };
    } finally {
      if (connection) {
        await connection.end();
        context.log("Connexion MySQL fermée.");
      }
    }
  },
});
