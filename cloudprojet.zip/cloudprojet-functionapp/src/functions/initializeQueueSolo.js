const { app } = require("@azure/functions");
const { QueueServiceClient } = require("@azure/storage-queue");

app.http("initializeQueueSolo", {
    methods: ["POST"],
    authLevel: "function",
    handler: async (req, context) => {
        try {
            const queueServiceClient = QueueServiceClient.fromConnectionString(
                process.env.AZURE_STORAGE_CONNECTION_STRING
            );
            const queueName = "quiz-questions-solo";
            const queueClient = queueServiceClient.getQueueClient(queueName);

            await queueClient.createIfNotExists();
            context.log(`Queue "${queueName}" created or already exists.`);

            return {
                status: 200,
                body: `Queue "${queueName}" initialized successfully.`,
            };
        } catch (error) {
            context.log.error("Error initializing the queue:", error);
            return {
                status: 500,
                body: `Failed to initialize queue: ${error.message}`,
            };
        }
    },
});
