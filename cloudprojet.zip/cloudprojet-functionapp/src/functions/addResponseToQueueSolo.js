const { app } = require("@azure/functions");
const { QueueServiceClient } = require("@azure/storage-queue");

app.http("addResponseToQueueSolo", {
    methods: ["POST"],
    authLevel: "function",
    handler: async (req, context) => {
        try {
            const data = await req.json();
            const { user_id, question_id, selected_option, session_key } = data;

            // Vérifier les paramètres
            if (!user_id || !question_id || !selected_option || !session_key) {
                return { status: 400, body: "Paramètres requis : user_id, question_id, selected_option, session_key." };
            }

            const enrichedData = {
                user_id,
                question_id,
                selected_option,
                session_key, // Utilisation directe de la clé reçue
            };

            // Envoi du message dans la file d'attente
            const queueClient = QueueServiceClient.fromConnectionString(process.env.AZURE_STORAGE_CONNECTION_STRING).getQueueClient("player-responses-solo");
            await queueClient.createIfNotExists();
            const message = Buffer.from(JSON.stringify(enrichedData)).toString("base64");
            await queueClient.sendMessage(message);

            return { status: 200, body: { message: "Réponse ajoutée avec succès à la file d'attente." } };
        } catch (error) {
            context.log.error("Erreur dans addResponseToQueue :", error.message);
            return { status: 500, body: { message: "Erreur interne.", details: error.message } };
        }
    },
});
