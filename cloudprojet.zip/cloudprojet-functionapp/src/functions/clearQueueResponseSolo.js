const { app } = require("@azure/functions");
const { QueueServiceClient } = require("@azure/storage-queue");

// Nom de la file d'attente
const queueName = "player-responses-solo";

// Initialisation du client Azure Storage Queue
const queueServiceClient = QueueServiceClient.fromConnectionString(process.env.AZURE_STORAGE_CONNECTION_STRING);

app.http("clearQueueResponseSolo", {
    methods: ["POST"],
    authLevel: "function",
    handler: async (req, context) => {
        try {
            // Récupérer les données de la requête
            const data = await req.json();
            const { user_id } = data;

            // Vérification que le champ user_id est fourni
            if (!user_id) {
                return {
                    status: 400,
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        error: "Paramètre requis : user_id.",
                    }),
                };
            }

            context.log(`Reçu : user_id = ${user_id}`);

            // Accéder à la file d'attente
            const queueClient = queueServiceClient.getQueueClient(queueName);

            // Vérifiez si la file d'attente existe
            const exists = await queueClient.exists();
            if (!exists) {
                return {
                    status: 404,
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                        error: `La file d'attente '${queueName}' est introuvable.`,
                    }),
                };
            }

            // Lire les messages dans la file d'attente
            const messages = await queueClient.receiveMessages({
                numberOfMessages: 32, // Max 32 messages par lot
                visibilityTimeout: 3, // Timeout pour rendre les messages invisibles temporairement
            });

            let matchCount = 0;

            for (const message of messages.receivedMessageItems) {
                try {
                    // Décoder et parser le message
                    const messageContent = JSON.parse(Buffer.from(message.messageText, "base64").toString("utf-8"));

                    // Vérifier si le user_id correspond
                    if (messageContent.user_id === user_id) {
                        // Supprimer le message correspondant
                        await queueClient.deleteMessage(message.messageId, message.popReceipt);
                        matchCount++;
                    }
                } catch (err) {
                    context.log.error(`Erreur lors du traitement d'un message : ${err.message}`);
                }
            }

            // Retourner le nombre de correspondances supprimées
            return {
                status: 200,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    message: "Messages correspondants supprimés avec succès.",
                    input: { user_id },
                    matches: matchCount,
                }),
            };
        } catch (error) {
            context.log.error("Erreur lors du traitement de la requête :", error.message);

            // Gestion des erreurs
            return {
                status: 500,
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    error: "Erreur interne.",
                    details: error.message,
                }),
            };
        }
    },
});
