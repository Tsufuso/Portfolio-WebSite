const { app } = require("@azure/functions");
const { QueueServiceClient } = require("@azure/storage-queue");

const queueName = "quiz-questions-solo";
const queueServiceClient = QueueServiceClient.fromConnectionString(process.env.AZURE_STORAGE_CONNECTION_STRING);

app.http("fetchQuestionsAndPushSolo", {
    methods: ["POST"],
    authLevel: "function",
    handler: async (req, context) => {
        try {
            context.log("Début de fetchQuestionsAndPushSolo...");

            // Obtenez le client de la file d'attente
            const queueClient = queueServiceClient.getQueueClient(queueName);
            context.log(`QueueClient initialisé pour la file : ${queueName}`);

            // Vérifiez si la file existe
            const exists = await queueClient.exists();
            if (!exists) {
                context.log.error(`La file '${queueName}' n'existe pas.`);
                return {
                    status: 404,
                    body: "File d'attente introuvable.",
                };
            }

            // Récupérer un message
            const response = await queueClient.receiveMessages({ numberOfMessages: 1 });
            if (!response.receivedMessageItems || response.receivedMessageItems.length === 0) {
                context.log("Aucune question disponible dans la file d'attente.");
                return {
                    status: 200,
                    body: "Aucune question disponible dans la file d'attente.",
                };
            }

            const message = response.receivedMessageItems[0];
            const question = JSON.parse(Buffer.from(message.messageText, "base64").toString("utf8"));
            context.log("Question décodée :", question);

            // Supprimer le message après traitement
            await queueClient.deleteMessage(message.messageId, message.popReceipt);
            context.log("Message supprimé avec succès :", message.messageId);

            return {
                status: 200,
                body: JSON.stringify(question) // Assurez-vous que `question` est correctement sérialisé en JSON
            };
            
        } catch (error) {
            context.log.error("Erreur dans fetchQuestionsAndPushSolo :", error.message);
            context.log.error(error.stack);

            return {
                status: 500,
                body: { message: "Erreur lors de l'envoi de la question.", details: error.message },
            };
        }
    },
});
